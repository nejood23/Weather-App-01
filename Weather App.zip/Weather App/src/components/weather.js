import { useState } from "react"



const Weather = () => {
    const [forecastData,setForecastData] = useState([]);
    const [city, setCity] = useState('');
    const [name, setName] = useState('');
    const [country, setCountry] = useState('');
   


    const fetchForeCastData = async (city) => {
        try {
            const res = await fetch(`https://api.weatherapi.com/v1/forecast.json?key=443372cdd6af4906ab3190358231308&q=${city}&days=4`);
            const data = await res.json();
            setForecastData(data.forecast.forecastday);
            setCountry(data.location.country);
            setName(data.location.name);
         
        } catch(error) {
            console.error('Error fetching forecast data:', error);
            alert("The City is not found !!");
            
            
            
        }
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        e.currentTarget.blur();
        
        if (city.trim() !== ''){
            fetchForeCastData(city);
            
        }
        e.target.reset();
        
        
    };
    return(
        <div className="overlay">
            <div className="container">
                <h3 className="header">Weather APP</h3>
                <div className="section">
                     
                     <form onSubmit={handleSubmit}>
                      <input type="text"   placeholders ="Search a city..." onChange={ e => setCity(e.target.value)} />
                    </form>
                </div>
                
                <div className="section_NC">
                    <div className="section_country">
                      {country && (
                       <h2>{country}</h2>
                      )}
                    </div>

                    <div className="section_name">
                        {name && (
                        <h2>{name}</h2>
                        )}
                    </div>
                </div>
                
                <div className="section_temp">
                   {forecastData.map((day) => (
                        <div key={day}>
                          
                            <div className="section_imD">
                                <p>{day.day.maxtemp_c} ˚C</p>
                                <img src={day.day.condition.icon} alt={day.day.condition.text} />
                                {/* <p>{day.day.condition.text}</p> */}
                                <p> {day.date}</p>
                             </div>
                             {/* <div className="date">
                                 <p> {day.date}</p>
                             </div> */}
                             
                        </div>
                      
                   ))}
                 </div> 
                
                
                
                
            
              
            </div>
            

        </div>
    ) 
}
export default Weather;