import Weather from './components/weather.js';

function App() {
  return (
    <div className="App">
       <Weather />
    </div>
  );
}

export default App;
